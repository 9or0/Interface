--[[
	Bagnon_Tooltips Localization
		English: default language
--]]

BAGNON_NUM_BAGS = 'Bags: %d'
BAGNON_NUM_BANK = 'Bank: %d'
BAGNON_EQUIPPED = 'Equipped'