-- This file is script-generated and should not be manually edited. 
-- Localizers may copy this file to edit as necessary. 
local AceLocale = LibStub:GetLibrary("AceLocale-3.0") 
local L = AceLocale:NewLocale("ComboPointsRedux", "enUS", true) 
if not L then return end 

-- Core.lua
L["Options"] = true
L["Lock"] = true
L["Disable Text Display"] = true
L["Disable Graphics Display"] = true
L["Alpha"] = true
L["Combo Point Icon Options"] = true
L["Orientation"] = true
L["Horizontal"] = true
L["Vertical"] = true
L["Combo Point Icon"] = true
L["Square"] = true
L["Circle"] = true
L["Triangle"] = true
L["Diamond"] = true
L["Graphics Scale"] = true
L["Spacing"] = true
L["Normal Color"] = true
L["Five Point Color"] = true
L["Combo Point Text Options"] = true
L["Font"] = true
L["Font Size"] = true
L["Text Color"] = true
L["Disable Poison Graphics"] = true
L["Poison Icon Options"] = true
L["Poison Icon Orientation"] = true
L["Poison Icon"] = true
L["Poison Scale"] = true
L["Poison Icon Spacing"] = true
L["Poison Normal Color"] = true
L["Poison Full Color"] = true

